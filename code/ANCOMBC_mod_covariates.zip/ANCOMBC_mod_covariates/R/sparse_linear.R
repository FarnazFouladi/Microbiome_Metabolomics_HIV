.sparse_linear = function(mat, wins_quant, method, soft, thresh_len,
                          n_cv, thresh_hard, max_p) { #local
  # Thresholding
  mat_thresh = function(mat, th, soft){
    mat_sign = sign(mat)
    mat_th = mat
    mat_th[abs(mat) <= th] = 0
    if (soft) {
      mat_th[abs(mat) > th] = abs(mat_th[abs(mat) > th]) - th
      mat_th = mat_th * mat_sign
    }
    return(mat_th)
  }
  
  # Threshold loss function
  thresh_loss = function(mat1, mat2, method, th, soft) {
    corr1 = cor(mat1, method = method, use = "pairwise.complete.obs")
    corr1[is.na(corr1)] <-0
    corr2 = cor(mat2, method = method, use = "pairwise.complete.obs")
    corr_diff = mat_thresh(corr1, th, soft) - corr2
    corr_diff[is.na(corr_diff)] = 0
    loss = norm(corr_diff, type = "F")
    return(loss)
  }
  
  # Filtering based on p-values
  p_filter = function(mat, mat_p, max_p){
    ind_p = mat_p
    ind_p[mat_p > max_p] = 0
    ind_p[mat_p <= max_p] = 1
    
    mat_filter = mat * ind_p
    return(mat_filter)
  }
  
  # Regularize the eigenvalues
  regularize_eigenvalues <- function(mat=cov_mat){
    
    # Decomposition
    decomp <- eigen(mat)
    org_eigenvalues <- decomp$values
    
    # Replace zero and negative eigenvalues with the minimum positive eigenvalue
    decomp$values[decomp$values <= 0] <- min(decomp$values[decomp$values>0])
    
    # Ratio of eigenvalues to the largest eigenvalue
    ratios <- decomp$values[1]/decomp$values
    
    # Difference between ratios
    diff_ratio <- sapply(2:length(ratios),function(x){ ratios[x]-ratios[x-1]})
    # Find the eigenvalue that corresponds to the maximum difference
    delta <- decomp$values[which(diff_ratio == max(diff_ratio,na.rm = T))]
    i = 1
    while(delta <0.01){
      delta <- decomp$values[which(diff_ratio == max(diff_ratio,na.rm = T))-i]
      i<- i+1
    }
    if(delta>1)
      delta <- 1
    
    # Winsorize eigenvalues with delta
    decomp$values[decomp$values<delta] <- delta
    
    cov_mat_pos <- decomp$vectors %*% diag(decomp$values) %*% pracma::inv(decomp$vectors)
    rownames(cov_mat_pos) <- rownames(mat)
    colnames(cov_mat_pos) <- colnames(mat)
    
    # Make the matrix symmetric
    cov_mat_pos[lower.tri(cov_mat_pos)] = t(cov_mat_pos)[lower.tri(cov_mat_pos)]
    
    
    return(list(cov_mat_pos,org_eigenvalues,decomp,delta))
    
  }
  
  is.positive.semidefinite <- function(matrix) {
    return((min(round(eigen(matrix)$values, 7))) >= 0)
  }
  
  
  # Sort taxa
  sort_taxa = sort(colnames(mat))
  mat = mat[, sort_taxa]
  
  # Winsorization
  mat = apply(mat, 2, function(x)
    DescTools::Winsorize(x, val = stats::quantile(x, probs = wins_quant, na.rm = TRUE)))
  
  # Co-occurrence matrix
  mat_occur = mat
  mat_occur[mat_occur != 0] = 1
  mat_occur[mat_occur == 0] = 0
  mat_occur[is.na(mat_occur)] = 0
  
  df_occur = as.data.frame(mat_occur)
  df_occur$sample_id = rownames(df_occur)
  df_occur_long = stats::reshape(df_occur,
                                 direction = "long",
                                 varying = list(colnames(mat_occur)),
                                 v.names = "occur",
                                 idvar = "sample_id",
                                 times = colnames(mat_occur),
                                 new.row.names = seq_len(nrow(df_occur)*ncol(df_occur)))
  names(df_occur_long)[names(df_occur_long) == "time"] = "taxon"
  df_occur_long = df_occur_long[df_occur_long$occur == 1, ]
  
  mat_cooccur = matrix(0, nrow = ncol(mat_occur), ncol = ncol(mat_occur))
  rownames(mat_cooccur) = colnames(mat_occur)
  colnames(mat_cooccur) = colnames(mat_occur)
  
  mat_cooccur_comp = crossprod(table(df_occur_long[, seq_len(2)]))
  idx = base::match(colnames(mat_cooccur_comp), colnames(mat_cooccur))
  mat_cooccur[idx, idx] = mat_cooccur_comp
  diag(mat_cooccur) = colSums(mat_occur)
  
  if (any(mat_cooccur < 10)) {
    warn_txt = sprintf(paste("There are some pairs of taxa that have insufficient (< 10) overlapping samples",
                             "Proceed with caution since the point estimates for these pairs are unstable",
                             "For pairs of taxa with no overlapping samples, the point estimates will be replaced with 0s,",
                             "and the corresponding p-values will be replaced with 1s",
                             "Please check `mat_cooccur` for details about the co-occurrence pattern",
                             sep = "\n"))
    warning(warn_txt)
  }
  
  # Sample size for training and test sets
  n = dim(mat)[1]
  n1 = n - floor(n/log(n))
  n2 = n - n1
  d = dim(mat)[2]
  
  
  if(method == "spearman"){
    # Convert to rank 
    mat <-apply(mat,2,function(x) {r <- rank(x,na.last = NA)
    x[!is.na(x)] <- r
    return(x)})
  }
  # Covariance matrix
  cov_mat <- stats::cov(mat,use = "pairwise.complete.obs")
  cov_mat[is.na(cov_mat)] <- 0
  
  # Regularize the covariance matrix
  regularized_list <- regularize_eigenvalues(cov_mat)
  cov_mat_pos <- regularized_list[[1]]
  org_eigenvalues <- regularized_list[[2]]
  decomp <- regularized_list[[3]]
  delta <- regularized_list[[4]]
  
  
  # Convert to correlation coefficient
  cov_mat_pos[mat_cooccur < 2] = 0
  cov_mat_pos[is.infinite(cov_mat_pos)] = 0
  
  # Check if it is positive semi-definite
  while(!is.positive.semidefinite(cov_mat_pos)) {
   
    regularized_list <- regularize_eigenvalues(cov_mat_pos)
    cov_mat_pos <- regularized_list[[1]]
    decomp <- regularized_list[[3]]
    delta <- regularized_list[[4]]
    cov_mat_pos[mat_cooccur < 2] = 0
    cov_mat_pos[is.infinite(cov_mat_pos)] = 0
  }
  cor_mat <- cov2cor(cov_mat_pos)
  
  
  # Correlation matrix
  #corr_list = suppressWarnings(Hmisc::rcorr(x = mat, type = method))
  #corr1 = corr_list$r
  corr = cor_mat
  
  # Get p-values
  # p_mat <- structure(as.numeric(unlist(mapply(diffcor::diffcor.one,
  #                                         emp.r =  cor_mat, 
  #                                         hypo.r = 0,
  #                                         alternative = "two.sided",
  #                                         digit = 30,
  #                                         n = mat_cooccur)["p",])),dim = dim(cor_mat))
  # colnames(p_mat) <- colnames(cor_mat)
  # rownames(p_mat) <- rownames(cor_mat)
  # 
  # adj_p <- matrix(p.adjust(p_mat,method = "holm"),nrow = nrow(p_mat),ncol = ncol(p_mat))
  # colnames(adj_p) <- colnames(cor_mat)
  # rownames(adj_p) <- rownames(cor_mat)
  
  
  
  
  # Cross-Validation
  # max_thresh = max(abs(corr[corr != 1]), na.rm = TRUE)
  # thresh_grid = seq(from = 0, to = max_thresh, length.out = thresh_len)
  # 
  # loss_mat = foreach(i = seq_len(n_cv), .combine = rbind) %dorng% {
  #     index = sample(seq_len(n), size = n1, replace = FALSE)
  #     mat1 = mat[index,]
  #     mat2 = mat[-index,]
  #     loss = vapply(thresh_grid, FUN = thresh_loss,
  #                   mat1 = mat1, mat2 = mat2,
  #                   method = method, soft = soft,
  #                   FUN.VALUE = double(1))
  # }
  # 
  # # Correlation matrix after thresholding
  # loss_vec = colMeans(loss_mat)
  # thresh_opt = thresh_grid[which.min(loss_vec)]
  # corr_th = mat_thresh(mat = corr, th = thresh_opt, soft = soft)
  # corr_th = mat_thresh(mat = corr_th, th = thresh_hard, soft = FALSE)
  # 
  # # Correlation matrix after filtering
  # corr_p = corr_list$P
  # diag(corr_p) = 0
  # corr_p[mat_cooccur < 2] = 1
  # corr_p[is.na(corr_p)] = 1
  # corr_p[is.infinite(corr_p)] = 1
  # corr_fl = p_filter(mat = corr, mat_p = corr_p, max_p = max_p)
  # corr_fl = mat_thresh(mat = corr_fl, th = thresh_hard, soft = FALSE)
  
  # Output
  result = list(#cv_error = loss_vec,
    #thresh_grid = thresh_grid,
    #thresh_opt = thresh_opt,
    mat_cooccur = mat_cooccur,
    corr = corr,
    #corr_p = p_mat,
    #cor_adjp = adj_p,
    #corr_th = corr_th,
    #corr_fl = corr_fl,
    cov_mat = cov_mat,
    covr_mat_pos = cov_mat_pos,
    decomp = decomp,
    org_eigenvalues = org_eigenvalues,
    delta = delta)
  return(result)
}

