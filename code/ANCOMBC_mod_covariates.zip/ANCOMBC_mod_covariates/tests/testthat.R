library("testthat")
packageVersion("ANCOMBC")
test_check("ANCOMBC")
